# Kaggle_Titanic_R
For a Course on how to get started with Kaggle.
